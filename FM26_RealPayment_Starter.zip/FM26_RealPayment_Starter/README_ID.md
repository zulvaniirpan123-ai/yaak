# FM26 Real Payment Starter (Midtrans Snap)

Starter proyek pembayaran server-side untuk game HTML FM26. Ini **belum siap menerima uang sungguhan** sampai pemilik proyek membuat akun merchant, melengkapi kredensial, meng-host server dengan HTTPS, dan menguji semua alur di sandbox. Jangan masukkan Server Key ke HTML atau membagikannya.

## Yang tersedia
- Akun email + kata sandi (hash bcrypt), cookie sesi HttpOnly, pembatasan request dasar.
- Paket harga/coin ditentukan di server, bukan dari input harga browser.
- Pembuatan transaksi Midtrans Snap melalui backend.
- Notifikasi diverifikasi menggunakan signature SHA-512, pemeriksaan order/nominal, dan ledger unik untuk mencegah coin ganda.
- Riwayat pesanan/status dan saldo coin berbayar disimpan di SQLite.
- File game HTML dengan UI akun dan tombol yang memanggil API backend.

## Catatan penting tentang saldo
Saldo coin berbayar (`paid_coins`) **sengaja terpisah** dari coin gratis yang dipakai gacha acak di game. Jangan menyatukan saldo berbayar dengan gacha acak. Jika ingin memonetisasi game, gunakan saldo berbayar untuk barang/fitur dengan hadiah yang sudah pasti dan dijelaskan di muka, atau ubah gacha menjadi hadiah gratis yang tidak dibeli dengan saldo berbayar. Untuk pengguna di bawah umur, minta orang tua/wali menangani dan menyetujui transaksi.

## Menjalankan lokal (komputer/hosting Node.js)
1. Pasang Node.js 20 atau lebih baru.
2. Salin `.env.example` menjadi `.env`.
3. Isi `JWT_SECRET` dengan string acak panjang (minimal 32 karakter) dan kredensial **Sandbox** Midtrans milik pengelola.
4. Jalankan `npm install`, lalu `npm start`.
5. Buka `http://localhost:3000`. File HTML harus disajikan oleh server ini, bukan dibuka dengan `file://`.
6. Atur Payment Notification URL di dashboard merchant ke `https://DOMAIN-ANDA/api/payments/notification` saat server sudah dipasang dengan HTTPS.
7. Uji alur transaksi di sandbox sampai webhook, pesanan, dan saldo berfungsi. Jangan aktifkan production sebelum lolos pengujian dan persyaratan merchant.

## Mengaktifkan production
- Pemilik/penanggung jawab dewasa harus menyelesaikan pendaftaran merchant, verifikasi, dan syarat gateway.
- Gunakan HTTPS, rahasiakan Server Key, atur `NODE_ENV=production`, `APP_ORIGIN=https://domain-anda`, `MIDTRANS_IS_PRODUCTION=true`, dan key production yang benar.
- Tambahkan monitoring, backup DB, kebijakan privasi, ketentuan pembelian/refund, proteksi CSRF sesuai deployment, dan tinjauan keamanan sebelum menerima pembayaran.
- Database SQLite cocok untuk starter kecil; evaluasi PostgreSQL/managed database untuk penggunaan publik.

## Harga demo
- Starter: Rp5.000 / 500 coin berbayar
- Popular: Rp15.000 / 1.500 coin berbayar
- Mega: Rp49.000 / 5.000 coin berbayar

Harga di atas hanya konfigurasi contoh. Ubah paket di `src/server.js` sebelum rilis dan tampilkan harga final secara jelas.

## Referensi resmi
- Midtrans Snap: https://docs.midtrans.com/docs/snap-snap-integration-guide
- Notifikasi pembayaran: https://docs.midtrans.com/docs/https-notification-webhooks
- Node.js client resmi: https://github.com/Midtrans/midtrans-nodejs-client
