require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const Database = require('better-sqlite3');
const crypto = require('crypto');
const path = require('path');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const APP_ORIGIN = process.env.APP_ORIGIN || `http://localhost:${PORT}`;
const JWT_SECRET = process.env.JWT_SECRET;
const SERVER_KEY = process.env.MIDTRANS_SERVER_KEY;
const CLIENT_KEY = process.env.MIDTRANS_CLIENT_KEY || '';
const PROD = process.env.MIDTRANS_IS_PRODUCTION === 'true';
const SNAP_URL = PROD ? 'https://app.midtrans.com/snap/v1/transactions' : 'https://app.sandbox.midtrans.com/snap/v1/transactions';
const SNAP_JS = PROD ? 'https://app.midtrans.com/snap/snap.js' : 'https://app.sandbox.midtrans.com/snap/snap.js';
if (!JWT_SECRET || JWT_SECRET.length < 32) throw new Error('JWT_SECRET wajib diisi dengan secret acak minimal 32 karakter.');
if (!SERVER_KEY) console.warn('MIDTRANS_SERVER_KEY belum diisi. Checkout tidak akan berfungsi sampai konfigurasi diisi.');

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '32kb' }));
app.use(cookieParser());
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false }));
app.use('/api/payments', rateLimit({ windowMs: 60 * 1000, limit: 12, standardHeaders: true, legacyHeaders: false }));

const db = new Database(path.join(__dirname, '..', 'fm26.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL,
 paid_coins INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS orders (
 id TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), package_id TEXT NOT NULL,
 amount INTEGER NOT NULL, coins INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
 snap_token TEXT, transaction_id TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 paid_at TEXT, FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS coin_ledger (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id),
 order_id TEXT NOT NULL UNIQUE REFERENCES orders(id), amount INTEGER NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);`);

const PACKAGES = Object.freeze({
 starter: { id: 'starter', label: 'Starter Pack', amount: 5000, coins: 500 },
 popular: { id: 'popular', label: 'Popular Pack', amount: 15000, coins: 1500 },
 mega: { id: 'mega', label: 'Mega Pack', amount: 49000, coins: 5000 }
});
function safeUser(row) { return { id: row.id, email: row.email, paidCoins: row.paid_coins }; }
function signInCookie(res, user) {
 const token = jwt.sign({ sub: String(user.id) }, JWT_SECRET, { expiresIn: '7d', issuer: 'fm26' });
 res.cookie('fm26_session', token, { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'lax', maxAge: 7 * 86400000, path: '/' });
}
function auth(req, res, next) {
 try {
  const token = req.cookies.fm26_session;
  if (!token) return res.status(401).json({ error: 'Silakan masuk ke akun game terlebih dahulu.' });
  const payload = jwt.verify(token, JWT_SECRET, { issuer: 'fm26' });
  const user = db.prepare('SELECT id,email,paid_coins FROM users WHERE id=?').get(Number(payload.sub));
  if (!user) return res.status(401).json({ error: 'Sesi tidak valid. Silakan masuk kembali.' });
  req.user = user; next();
 } catch { return res.status(401).json({ error: 'Sesi kedaluwarsa. Silakan masuk kembali.' }); }
}
app.get('/api/config', (_req, res) => res.json({ clientKey: CLIENT_KEY, snapJs: SNAP_JS, packages: Object.values(PACKAGES).map(({id,label,amount,coins})=>({id,label,amount,coins})), mode: PROD ? 'production' : 'sandbox' }));
app.post('/api/auth/register', (req,res) => {
 const email = String(req.body.email || '').trim().toLowerCase(); const password = String(req.body.password || '');
 if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 190) return res.status(400).json({error:'Email tidak valid.'});
 if (password.length < 10 || password.length > 200) return res.status(400).json({error:'Kata sandi minimal 10 karakter.'});
 try { const hash = bcrypt.hashSync(password, 12); const result = db.prepare('INSERT INTO users(email,password_hash) VALUES(?,?)').run(email,hash); const user=db.prepare('SELECT id,email,paid_coins FROM users WHERE id=?').get(result.lastInsertRowid); signInCookie(res,user); res.json({user:safeUser(user)}); }
 catch(e) { if (String(e.code)==='SQLITE_CONSTRAINT_UNIQUE') return res.status(409).json({error:'Email sudah terdaftar.'}); console.error(e); res.status(500).json({error:'Gagal membuat akun.'}); }
});
app.post('/api/auth/login', (req,res) => {
 const email=String(req.body.email||'').trim().toLowerCase(), password=String(req.body.password||'');
 const user=db.prepare('SELECT * FROM users WHERE email=?').get(email);
 if(!user || !bcrypt.compareSync(password,user.password_hash)) return res.status(401).json({error:'Email atau kata sandi salah.'});
 signInCookie(res,user); res.json({user:safeUser(user)});
});
app.post('/api/auth/logout', (_req,res)=>{res.clearCookie('fm26_session',{path:'/'});res.json({ok:true});});
app.get('/api/me', auth, (req,res)=>res.json({user:safeUser(req.user)}));
app.get('/api/orders', auth, (req,res)=>{
 const rows=db.prepare('SELECT id,package_id,amount,coins,status,created_at,paid_at FROM orders WHERE user_id=? ORDER BY created_at DESC LIMIT 30').all(req.user.id);
 res.json({orders:rows});
});
app.post('/api/payments/create', auth, async (req,res) => {
 const pack=PACKAGES[String(req.body.packageId||'')];
 if(!pack) return res.status(400).json({error:'Paket tidak dikenal.'});
 if(!SERVER_KEY || SERVER_KEY.includes('REPLACE_ME')) return res.status(503).json({error:'Server pembayaran belum dikonfigurasi oleh pengelola game.'});
 const orderId=`FM26-${req.user.id}-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
 db.prepare('INSERT INTO orders(id,user_id,package_id,amount,coins,status) VALUES(?,?,?,?,?,?)').run(orderId,req.user.id,pack.id,pack.amount,pack.coins,'pending');
 try {
  const basic=Buffer.from(`${SERVER_KEY}:`).toString('base64');
  const response=await fetch(SNAP_URL,{method:'POST',headers:{'Accept':'application/json','Content-Type':'application/json','Authorization':`Basic ${basic}`},body:JSON.stringify({transaction_details:{order_id:orderId,gross_amount:pack.amount},item_details:[{id:pack.id,price:pack.amount,quantity:1,name:`FM26 ${pack.label}`}],customer_details:{email:req.user.email},callbacks:{finish:`${APP_ORIGIN}/?payment=finish`}})});
  const data=await response.json();
  if(!response.ok || !data.token) { console.error('Midtrans create transaction failed',data); db.prepare("UPDATE orders SET status='failed' WHERE id=?").run(orderId); return res.status(502).json({error:'Gateway pembayaran gagal membuat transaksi. Coba lagi nanti.'}); }
  db.prepare('UPDATE orders SET snap_token=? WHERE id=?').run(data.token,orderId);
  res.json({orderId,token:data.token,redirectUrl:data.redirect_url,clientKey:CLIENT_KEY,snapJs:SNAP_JS});
 } catch(e) { console.error(e); db.prepare("UPDATE orders SET status='failed' WHERE id=?").run(orderId); res.status(502).json({error:'Tidak dapat menghubungi gateway pembayaran.'}); }
});

// Midtrans notification: signature validation + amount/order checks + idempotent ledger credit.
app.post('/api/payments/notification', (req,res) => {
 try {
  const n=req.body||{};
  const expected=crypto.createHash('sha512').update(String(n.order_id||'')+String(n.status_code||'')+String(n.gross_amount||'')+SERVER_KEY).digest('hex');
  const received=String(n.signature_key||'');
  if(!SERVER_KEY || received.length!==expected.length || !crypto.timingSafeEqual(Buffer.from(received),Buffer.from(expected))) return res.status(403).json({error:'Signature tidak valid.'});
  const order=db.prepare('SELECT * FROM orders WHERE id=?').get(String(n.order_id||''));
  if(!order) return res.status(404).json({error:'Order tidak ditemukan.'});
  if(Number(n.gross_amount)!==order.amount) return res.status(400).json({error:'Nominal transaksi tidak cocok.'});
  const successful=(n.transaction_status==='settlement') || (n.transaction_status==='capture' && n.fraud_status==='accept');
  const cancelish=['cancel','deny','expire','failure'].includes(String(n.transaction_status));
  const tx=db.transaction(()=>{
   if(successful && order.status!=='paid') {
    db.prepare("UPDATE orders SET status='paid',transaction_id=?,paid_at=CURRENT_TIMESTAMP WHERE id=? AND status!='paid'").run(String(n.transaction_id||''),order.id);
    const now=db.prepare('SELECT status FROM orders WHERE id=?').get(order.id);
    if(now.status==='paid') {
     const inserted=db.prepare('INSERT OR IGNORE INTO coin_ledger(user_id,order_id,amount) VALUES(?,?,?)').run(order.user_id,order.id,order.coins);
     if(inserted.changes===1) db.prepare('UPDATE users SET paid_coins=paid_coins+? WHERE id=?').run(order.coins,order.user_id);
    }
   } else if(cancelish && order.status==='pending') db.prepare('UPDATE orders SET status=? WHERE id=?').run(String(n.transaction_status),order.id);
  });
  tx(); res.status(200).json({ok:true});
 } catch(e) { console.error('Notification error',e); res.status(500).json({error:'Notification processing failed.'}); }
});
app.get('/api/payments/status/:orderId', auth, (req,res)=>{
 const order=db.prepare('SELECT id,package_id,amount,coins,status,created_at,paid_at FROM orders WHERE id=? AND user_id=?').get(req.params.orderId,req.user.id);
 if(!order) return res.status(404).json({error:'Order tidak ditemukan.'});
 const user=db.prepare('SELECT paid_coins FROM users WHERE id=?').get(req.user.id);
 res.json({order,paidCoins:user.paid_coins});
});
app.use(express.static(path.join(__dirname,'..','public')));
app.get('*', (_req,res)=>res.sendFile(path.join(__dirname,'..','public','index.html')));
app.listen(PORT,()=>console.log(`FM26 payment starter listening on ${PORT} (${PROD?'production':'sandbox'})`));
